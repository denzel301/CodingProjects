var roundsInput = document.getElementById("rounds");
    var remainingRounds = 0;
    var playerWins = 0;
    var computerWins = 0;
    var overallWinner = "";


// starts game all values are set to 0
    function startGame() {
      remainingRounds = parseInt(roundsInput.value);
      playerWins = 0;
      computerWins = 0;
      overallWinner = "";

      document.getElementById("gameplay").style.display = "block";
      updateRemainingRounds();
      updateOverallWinner("");
      resetResult();
      // once the remaining rounds hit 0 that will be the end of the game

      if (remainingRounds === 0) {
        endGame();
      }
    }

    function updateRemainingRounds() {
      document.getElementById("remaining-rounds").textContent = remainingRounds;
    }
     
    function updateOverallWinner(winner) {
        document.getElementById("overall-winner").textContent = winner;
      }
    
    function resetResult() {
      document.getElementById("result").textContent = "";
    }

    function play(playerChoice) {
      var computerChoice = generateComputerChoice();
      displayComputerPlay(computerChoice);
      var roundResult = determineRoundResult(playerChoice, computerChoice);
      displayRoundResult(roundResult);
      updateScores(roundResult);
      remainingRounds--;

      updateRemainingRounds();

      if (remainingRounds === 0) {
        endGame();
      }
    }
//this function makes the computer choose a random value
    function generateComputerChoice() {
      var choices = ["rock", "scissors", "paper", "lizard", "spock"];
      var randomIndex = Math.floor(Math.random() * choices.length);
      return choices[randomIndex];
    }
// function to display thw computers choice
    function displayComputerPlay(choice) {
      document.getElementById("computer-choice").textContent = choice;
    }

// function to determine the winner for each round

    function determineRoundResult(playerChoice, computerChoice) {
      var rules = {
        rock: { beats: ["scissors", "lizard"] },
        scissors: { beats: ["paper", "lizard"] },
        paper: { beats: ["rock", "spock"] },
        lizard: { beats: ["paper", "spock"] },
        spock: { beats: ["rock", "scissors"] }
      };

      if (playerChoice === computerChoice) {
        return "You both tied!";
      } else if (rules[playerChoice].beats.includes(computerChoice)) {
        return "Player wins!";
      } else {
        return "Computer wins!";
      }
    }

    function displayRoundResult(result) {
      document.getElementById("result").textContent = result;
    }
   // everytime the round results Player Win this function adds 1 to player points
    function updateScores(roundResult) {
      if (roundResult === "Player wins!") {
        playerWins++;
      } else if (roundResult === "Computer wins!") {
        computerWins++;
      }
    }

    function endGame() {
      if (playerWins > computerWins) {
        overallWinner = "Human wins after winning " + playerWins + " of " + roundsInput.value + " rounds.";
      } else if (playerWins < computerWins) {
        overallWinner = "Computer wins after winning " + computerWins + " of " + roundsInput.value + " rounds.";
      } else {
        overallWinner = "It's a tie!";
      }

      updateOverallWinner(overallWinner);
      document.getElementById("gameplay").style.display = "none";
    }